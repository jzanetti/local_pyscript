from .methods import hbe
from .methods import sw
from .methods import wf 
from .methods import lpb4
